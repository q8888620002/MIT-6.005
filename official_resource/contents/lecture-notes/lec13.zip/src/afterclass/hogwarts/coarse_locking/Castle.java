package afterclass.hogwarts.coarse_locking;

public interface Castle {

}
