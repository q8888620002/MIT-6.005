package markup;

import static org.junit.Assert.*;

import org.junit.Test;

public class GallileoTest {

    @Test
    public void test() {
        fail("Not yet implemented");
    }

}
