package markup;

public class SyntaxErrorException extends Exception {
    public SyntaxErrorException(String msg) {
        super(msg);
    }
}
