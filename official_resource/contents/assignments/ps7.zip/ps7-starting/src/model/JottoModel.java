package model;

/**
 * // TODO Write specifications for your JottoModel!
 */
public class JottoModel {
	
	/**
	 * // TODO Write specifications for the makeGuess function.
	 */
	public void makeGuess(String guess) {
		// TODO Problem 1
	}
}
