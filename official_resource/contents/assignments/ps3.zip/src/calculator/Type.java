package calculator;

/*
 * TODO define your symbols and groups from problem 1 here
 */

/**
 * Token type.
 */
enum Type {
	// TODO define for problem 1
}